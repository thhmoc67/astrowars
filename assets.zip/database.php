

<?php
$connect=mysqli_connect('localhost','upasana','anasapu@123','Astrowars');

if(mysqli_connect_errno($connect))
{
		echo 'Failed to connect';
}

?>
