<?php
$con=mysqli_connect("localhost","upasana","anasapu@123") or die("could'n be connected");
$db=mysqli_select_db($con,"Astrowars");
?>